$(document).ready();

/* 
function damePosicion(){
    $('body').on('mousemove', ubicate);
}

function ubicate(){
    console.log('Ubicacion X', event.clientX);
    console.log('Ubicacion Y', event.clientY);
} */

$(document).mousemove(function(e) {
	$('#drone').offset({
		left: e.pageX,
		top: e.pageY + 20
	});
	$('#drone').position();
});

$(document).mousemove(function(e) {
	$('#pilot').offset({
		left: e.pageX
	});
	$('#pilot').position();
});

$("#piedra").hover( function () {
	alert("hello"); 
  });

$(document).ready(init);

function init() {

	damePosicionDrone();
	damePosicionPiloto();
}

function ubicate(){
    console.log('Ubicacion X', event.clientX);
    console.log('Ubicacion Y', event.clientY);
}

function damePosicionDrone(){
	$('#drone').on('mousemove', ubicate); 
}
	
function damePosicionPiloto(){
	$('#piloto').on('mousemove', ubicate); 
}

/* 
function seUnenDronePiloto(){
var posicionDelDrone = 


	if 
}

*/

damePosicionDrone();